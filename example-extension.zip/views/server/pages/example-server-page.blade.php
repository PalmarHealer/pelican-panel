<x-filament-panels::page>
    <div class="space-y-6">
        <x-filament::section>
            <x-slot name="heading">
                Example Server Feature
            </x-slot>

            <x-slot name="description">
                This is an example server panel page with custom permission management.
            </x-slot>

            <div class="prose dark:prose-invert max-w-none">
                <p>
                    This page demonstrates how extensions can register custom server panel pages with dynamic permission checks.
                </p>

                <h3>Features:</h3>
                <ul>
                    <li>Custom permission-based access control (requires 'example_feature.read' permission)</li>
                    <li>Dynamic permission display showing what user can/cannot do</li>
                    <li>Egg-based filtering support (can show only for specific server types)</li>
                    <li>Full access to Filament components and server context</li>
                </ul>
            </div>
        </x-filament::section>

        <x-filament::section>
            <x-slot name="heading">
                Your Permissions
            </x-slot>

            <x-slot name="description">
                These are the extension permissions you have for this server.
            </x-slot>

            <div class="space-y-4">
                @forelse($userPermissions as $category)
                    <div class="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                        <div class="flex items-center gap-2 mb-2">
                            @if(isset($category['icon']))
                                <x-filament::icon
                                    :icon="$category['icon']"
                                    class="h-5 w-5 text-gray-500 dark:text-gray-400"
                                />
                            @endif
                            <h4 class="text-lg font-semibold">{{ ucfirst(str_replace('_', ' ', $category['category'])) }}</h4>
                        </div>
                        <p class="text-sm text-gray-600 dark:text-gray-400 mb-3">{{ $category['description'] }}</p>

                        <div class="space-y-2">
                            @foreach($category['permissions'] as $action => $permission)
                                <div class="flex items-center gap-2">
                                    @if($permission['granted'])
                                        <x-filament::icon
                                            icon="tabler-circle-check"
                                            class="h-5 w-5 text-success-500"
                                        />
                                    @else
                                        <x-filament::icon
                                            icon="tabler-circle-x"
                                            class="h-5 w-5 text-danger-500"
                                        />
                                    @endif

                                    <div class="flex-1">
                                        <code class="text-sm">{{ $permission['key'] }}</code>
                                        <p class="text-xs text-gray-600 dark:text-gray-400">{{ $permission['description'] }}</p>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @empty
                    <div class="text-center py-8 text-gray-500 dark:text-gray-400">
                        <x-filament::icon
                            icon="tabler-lock"
                            class="h-12 w-12 mx-auto mb-2 opacity-50"
                        />
                        <p>No extension permissions found.</p>
                    </div>
                @endforelse
            </div>
        </x-filament::section>

        <x-filament::section>
            <x-slot name="heading">
                Extension Info
            </x-slot>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <strong>Extension ID:</strong> example-extension
                </div>
                <div>
                    <strong>Panel:</strong> Server
                </div>
                <div>
                    <strong>Version:</strong> 1.0.0
                </div>
                <div>
                    <strong>Status:</strong> <span class="text-success-600">Active</span>
                </div>
            </div>
        </x-filament::section>
    </div>
</x-filament-panels::page>
