<div class="text-xs text-gray-500 dark:text-gray-400 text-center p-2">
    Example Extension v1.0.0 is active
</div>
