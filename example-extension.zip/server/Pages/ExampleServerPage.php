<?php

namespace App\Filament\Server\Pages\Extensions\ExampleExtension;

use App\Filament\Server\Pages\Concerns\HasExtensionPermissions;
use Filament\Facades\Filament;
use Filament\Pages\Page;

class ExampleServerPage extends Page
{
    use HasExtensionPermissions;

    protected static ?string $slug = 'extensions/example-server-page';

    protected static string|\BackedEnum|null $navigationIcon = 'tabler-sparkles';

    protected string $view = 'extensions.example-extension.server.pages.example-server-page';

    protected static ?int $navigationSort = 50;

    public function mount(): void
    {
        // Get all permissions the user has for this server using the trait
        $this->userPermissions = $this->getExtensionPermissions('example-extension');
    }

    public static function getNavigationLabel(): string
    {
        return 'Example Feature';
    }

    public function getTitle(): string
    {
        return 'Example Server Feature';
    }

    public function getHeading(): string
    {
        $server = Filament::getTenant();
        return 'Example Feature for ' . $server?->name;
    }

    /**
     * Check if the user can access this extension page.
     * Requires the custom 'example_feature.read' permission.
     */
    public static function canAccess(): bool
    {
        return user()?->can('example_feature.read', Filament::getTenant()) ?? false;
    }
}
